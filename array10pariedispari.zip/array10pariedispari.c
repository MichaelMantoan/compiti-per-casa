#include <stdio.h>

int main(void) {
int array[9];
int num1;
int num2;
int num3;
int num4;
int num5;
int num6;
int num7;
int num8;
int num9;
int num10;
scanf("%d",&num1);
scanf("%d",&num2);
scanf("%d",&num3);
scanf("%d",&num4);
scanf("%d",&num5);
scanf("%d",&num6);
scanf("%d",&num7);
scanf("%d",&num8);
scanf("%d",&num9);
scanf("%d",&num10);
array[0]=num1;
array[1]=num2;
array[2]=num3;
array[3]=num4;
array[4]=num5;
array[5]=num6;
array[6]=num7;
array[7]=num8;
array[8]=num9;
array[9]=num10;
if(num1%2==0) 
   printf("%d",num1); 

 if(num2%2==0) 
      printf("%d",num2); 


if(num3%2==0) 
      printf("%d",num3); 


if(num4%2==0) 
      printf("%d",num4);


if(num5%2==0) 
      printf("%d",num5);


if(num6%2==0) 
      printf("%d",num6);


if(num7%2==0) 
      printf("%d",num7);


if(num8%2==0) 
      printf("%d",num8);

if(num9%2==0) 
      printf("%d",num9);


if(num10%2==0) 
      printf("%d",num10);

if(num1%2!=0) 
      printf("%d",num1);
if(num2%2!=0) 
      printf("%d",num2);
if(num3%2!=0) 
      printf("%d",num3); 
if(num4%2!=0) 
      printf("%d",num4);
if(num5%2!=0) 
      printf("%d",num5); 
if(num6%2!=0) 
      printf("%d",num6);
if(num7%2!=0) 
      printf("%d",num7);
if(num8%2!=0) 
      printf("%d",num8);
if(num9%2!=0) 
      printf("%d",num9);
if(num10%2!=0) 
      printf("%d",num10);

   

return 0;


}